# LimaruResourcePack
Official resource pack for Limaru. Contains all models and textures.

# How to Contribute
1. Create a Github account if you haven't done so already (The free version will suffice).
2. Fork this repository (Press "Fork" on the top right hand corner).
3. Clone this repository to your minecraft/resourcepacks folder. We recommend using [Github Desktop](https://desktop.github.com/) to do so.
4. Edit the resource pack directly in your minecraft/resourcepacks folder.
5. Stage the changes and commit (go to Github Desktop and press the "Commit" button)
6. Once you are done, open a pull request here. We will review it (or maybe not) and apply the changes in the main repository.
