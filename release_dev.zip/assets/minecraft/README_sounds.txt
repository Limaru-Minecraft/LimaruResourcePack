Custom folders:
- Train: For all train sounds (categorise by rolling stock)
- Track: For all track sounds (categorise by track type)
- Announcement: For all announcements. (categorise by line)